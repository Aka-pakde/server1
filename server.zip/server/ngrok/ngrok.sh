#!/bin/bash
cp ngrok.zip $HOME
unzip ngrok
