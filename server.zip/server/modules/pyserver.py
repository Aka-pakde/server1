import SimpleHTTPServer 
import SocketServer 
try:
 ht="127.0.0.1"
 pt=4444
 Handler = SimpleHTTPServer.SimpleHTTPRequestHandler 
 httpd = SocketServer.TCPServer((ht, pt), Handler) 
 print "serving at port http://"+ht+":"+str(pt) 
 httpd.serve_forever()
except KeyboardInterrupt:
 print ''
 print 'ctrl+c detected'