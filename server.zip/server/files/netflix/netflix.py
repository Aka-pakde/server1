#python2

def netflixcre():
 try:
  target = "files/netflix/l.txt"
  file = open(target, "r")
  text = file.read()
  file.close()
  print text
 except IOError:
  print ''
  print "No data found !"
  print ''

